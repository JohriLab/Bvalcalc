# The B-value calculator: efficient estimation of expected genetic diversity under background selection

Jacob Marsh and Parul Johri
UNC Chapel Hill, NC
